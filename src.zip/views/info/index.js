import React, { Component } from "react";

export default class Info extends Component {
  render() {
    return <div> 咨询</div>;
  }
}
