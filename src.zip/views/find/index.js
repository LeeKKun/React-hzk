import React, { Component } from "react";

export default class Find extends Component {
  render() {
    return <div> 找房</div>;
  }
}
