// config.js
/*
  通用配置
*/
export const IMG_BASE_URL = "http://localhost:8080";
