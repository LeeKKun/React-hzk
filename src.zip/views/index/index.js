import React, { Component } from "react";
import { Carousel, Flex, Grid, WingBlank } from "antd-mobile";
import "./index.scss";
import axios from "axios";

// 菜单图标
import nav1 from "../assets/images/nav-1.png";
import nav2 from "../assets/images/nav-2.png";
import nav3 from "../assets/images/nav-3.png";
import nav4 from "../assets/images/nav-4.png";

axios.defaults.baseURL = "http://localhost:8080";

export default class Index extends Component {
  state = {
    swiperData: [],
    isloaded: false,
    groupData: []
  };

  loadSwiper = async () => {
    let res = await axios.get("/home/swiper");
    console.log(res);
    this.setState({
      swiperData: res.data.body
    });
  };

  // 加载租房小组数据
  loadGroup = async () => {
    let res = await axios.get("/home/groups");
    console.log(res);
    this.setState({
      groupData: res.data.body
    });
  };

  // 轮播图
  renderSwiper = () => {
    return this.state.swiperData.map((item, index) => (
      // eslint-disable-next-line jsx-a11y/alt-text
      <img
        src={`http://localhost:8080${item.imgSrc}`}
        key={item.id}
        onLoad={() => {
          // 窗口尺寸变化时->触发resize事件->重新设置动态高
          window.dispatchEvent(new Event("resize"));
          // this.setState({ imgHeight: 'auto', isLoaded: true})
          this.setState({
            isloaded: true
          });
        }}
      />
    ));
  };

  // 菜单
  rendercaidan = () => {
    const navs = [
      {
        id: 1,
        img: nav1,
        title: "整租",
        path: "/home/list"
      },
      {
        id: 2,
        img: nav2,
        title: "合租",
        path: "/home/list"
      },
      {
        id: 3,
        img: nav3,
        title: "地图找房",
        path: "/map"
      },
      {
        id: 4,
        img: nav4,
        title: "去出租",
        path: "/rent/add"
      }
    ];
    const navtag = navs.map(item => (
      <Flex.Item key={item.id}>
        <img src={item.img} alt="图片无法显示" />
        <p>{item.title}</p>
      </Flex.Item>
    ));
    return <Flex>{navtag}</Flex>;
  };

  // 租房小屋
  rendGroup = () => {
    return (
      <div className="group">
        <Flex className="group-title" justify="between">
          <h3>租房小组</h3>
          <span>更多</span>
        </Flex>

        <Grid
          data={this.state.groupData}
          columnNum={2}
          square={false}
          renderItem={item => {
            return (
              <Flex className="grid-item" justify="between">
                <div className="desc">
                  <h3>{item.title}</h3>
                  <p>{item.desc}</p>
                </div>
                <img src={`http://localhost:8080${item.imgSrc}`} alt="" />
              </Flex>
            );
          }}
        />
      </div>
    );
  }
  componentDidMount() {
    this.loadSwiper();
    this.rendercaidan();
    this.loadGroup();
  }
  render() {
    return (
      <div>
        {/* 顶部轮播图 */}
        <Carousel autoplay={this.state.isloaded} infinite>
          {this.renderSwiper()}
        </Carousel>

        {/* 菜单图标 */}
        {this.rendercaidan()}

        {/* 租房小组 */}
        {this.rendGroup()}

        {/* 最新资讯 */}
        <div className="news">
          <h3 className="group-title">最新资讯</h3>
          <WingBlank size="md">
            
          </WingBlank>
        </div>
      </div>
    );
  }
}
